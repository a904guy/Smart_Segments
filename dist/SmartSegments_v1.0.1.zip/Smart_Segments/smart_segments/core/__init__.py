"""Core AI processing components for Smart Segments plugin"""
