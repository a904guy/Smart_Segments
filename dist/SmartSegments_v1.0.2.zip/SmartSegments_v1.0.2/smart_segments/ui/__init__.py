"""UI components for Smart Segments plugin"""
